#!/bin/bash

bash ./grupo1.sh

bash ./grupo2.sh
echo "NOMBRE DE LA MÁQUINA"
hostname
echo "FECHA DE HOY"
date

echo "Pulse intro para continuar"
read

